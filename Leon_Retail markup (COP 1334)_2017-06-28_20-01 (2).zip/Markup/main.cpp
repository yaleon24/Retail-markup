#include <iostream>

using namespace std;

  double calcRetail(double,double );

int main()
{
    double cost=0;
    double markup=0;
    //continue while both the wholesale and markup are positive.
    //Do not allow either a negative price or a negative


    while(cost>=0 && markup >= 0){
    cout << "Enter the wholesale price of the item:" << endl;
    cin>>cost;

    if(cost<0){
    break;
    }

    cout << "Enter the percent markup of the item:" << endl;
    cin>>markup;
     if(markup<0){
        break;
    }

    cout << "$" << calcRetail(cost, markup) << endl;
    }
    return 0;
}
   double calcRetail(double cost, double markup){
   double result;

   markup=(markup/100)*cost;
   cost=markup+cost;
   result=cost;
   return result;
   }
